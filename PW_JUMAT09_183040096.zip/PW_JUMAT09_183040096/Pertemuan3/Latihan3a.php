<html>
<head>
	<meta charset="UTF-8">
	<title>Latihan 3a</title>
	<style>
		.ganti_style {
			color : #8c782d;
			font-size: 28px;
			font-family: arial;
			font-weight: bold;
			font-style: italic;
			line-height: 50px;
		}

		.box_model {
			border: 1px solid black ;
			height: 50px;
			width: 600px;
			border-radius: 5px;
			box-shadow: 2px 2px 20px black;

		}
	</style>



</head>
<body>
	<?php 

		function gantiStyle ($tulisan) {
			echo "<div class= 'ganti_style box_model'>$tulisan</div>";

		}echo gantiStyle("Selamat Datang di Praktikum PW 2019");	

	  // echo gantiStyle ("Selamat Datang di Praktikum PW 2019" , "ganti_style" , "box_model");
	 ?>
	
</body>
</html>