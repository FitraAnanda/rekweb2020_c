<html>
<head>
	<meta charset="UTF-8">
	<title>latihan 3b</title>
	<style>
		.kotak{
			border: 1px solid black ;
			width: 600px;
			border-radius: 5px;
			text-align: justify;
			padding: 3px;
		}
	</style>
</head>
<body>
	<?php 
$jawabanIsset = "Isset adalah = salah satu fungsi php yang berguna untuk memeriksa suatu objek dari nilai inputan form, Dimana nilai yang diperiksa tersebut merupakan nilai true yang dilempar dari suatu form walaupun form tersebut tidak terisi atau kosong.<br><br>";

$jawabanEmpty = "Empty adalah =  fungsi yang berperan memeriksa kebalikan dari kinerja isset() atau mencari nilai lemparan dari suatu form yang tidak terisi atau kosong.";
 

function soal(){
		echo "<div>";
	 $jawabanIssetlokal = $GLOBALS['jawabanIsset'];
	 $jawabanEmptylokal = $GLOBALS['jawabanEmpty'];
	 
	 echo "<div class='kotak'> $jawabanIssetlokal $jawabanEmptylokal</div>";
}
soal();
 ?>
	
</body>
</html>






