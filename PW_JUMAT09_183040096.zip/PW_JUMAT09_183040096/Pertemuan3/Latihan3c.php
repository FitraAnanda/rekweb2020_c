<?php 

	$jarijari = 10;

	echo "<h4>Menghitung Luas Lingkaran</h4>";
	function hitungLuasLingkaran  () {
		$jarijarilokal = $GLOBALS['jarijari'];
		$luas = 3.14 * $GLOBALS['jarijari'] * $GLOBALS['jarijari'];
		echo "jari-jari lingkaran : " . $jarijarilokal . " cm";
		echo "<br>";
		echo "Luas Lingkaran : " . $luas;
		echo " cm <sup>2</sup>";
		echo "<hr>";
	} 
	hitungLuasLingkaran();

	$jarijarix = 20;
	echo "<h4>Menghitung Keliling Lingkaran</h4>";
	function hitungKelilingLingkaran  () {
		$jarijarixlokal = $GLOBALS['jarijarix'];
		$keliling = 3.14 * ($GLOBALS['jarijarix'] + $GLOBALS['jarijarix']);
		echo "jari-jari lingkaran : " . $jarijarixlokal . " cm";
		echo "<br>";
		echo "keliling Lingkaran : " . $keliling. " cm";
		echo "<hr>";
	} 
	hitungKelilingLingkaran();
	
 ?>