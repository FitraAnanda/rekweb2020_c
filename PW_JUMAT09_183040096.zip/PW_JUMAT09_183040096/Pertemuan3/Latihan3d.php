<?php 

function urutanAngka ($angka){
	$k = 1;
	for ( $i = 0; $i<=$angka; $i++){
		//echo $i;
		for ($j=0; $j<=$i; $j++){
			echo $k ."     ";
			$k++;
		}
		echo "<br>";
	}
}
echo urutanAngka(5);
 //baris kelima hakikatnya sejajar namun angka terlihat kurang sinkron (karena sudah terdiri dari dua angka).





 ?>