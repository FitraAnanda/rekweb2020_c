<!DOCTYPE html>
<html>
<head>
	<title>Tugas 2</title>
</head>
<body>

<?php 
	$Mobil = [
		[
			"no" => "1",
			"gambar" => "2.PNG",
			"Merek/Model" => "Lamborghini Venano",
			"Tahun Produksi" => "2013-2014",
			"Produksi Negara" => "italia",
			"Speed" => "356 Km/h",
			"Harga" => "Rp. 65 Miliar"

		],
		[
			"no" => "2",
			"gambar" => "2.PNG",
			"Merek/Model" => "Lykan Hypersport",
			"Tahun Produksi" => "2016-2017",
			"Produksi Negara" => "Arab",
			"Speed" => "395 Km/h",
			"Harga" => "80 Miliar"
		],
		[
			"no" => "3",
			"gambar" => "2.PNG",
			"Merek/Model" => "Ferrari F60 Amerika",
			"Tahun Produksi" => "2012-2013",
			"Produksi Negara" => "America",
			"Speed" => "320 km/h",
			"Harga" => "40 Miliar"
		],
		[
			"no" => "4",
			"gambar" => "2.PNG",
			"Merek/Model" => "Bugati Veyron super Sports",
			"Tahun Produksi" => "2017-2018",
			"Produksi Negara" => "Swedia",
			"Speed" => "415 km/h",
			"Harga" => "50 Miliar"
		],
		[
			"no" => "5",
			"gambar" => "2.PNG",
			"Merek/Model" => "Lamborghini Reventon",
			"Tahun Produksi" => "2017-2018",
			"Produksi Negara" => "italia",
			"Speed" => " 330 km/h",
			"Harga" => "65 Miliar"
		],
		[
			"no" => "6",
			"gambar" => "2.PNG",
			"Merek/Model" => "Aston Martin",
			"Tahun Produksi" => "2010-2011",
			"Produksi Negara" => "Swedia",
			"Speed" => "#20 Km/h",
			"Harga" => "35 Miliar"
		],
		[
			"no" => "7",
			"gambar" => "2.PNG",
			"Merek/Model" => "Ferrari LaFerrari ",
			"Tahun Produksi" => "2017-2018",
			"Produksi Negara" => "Italia",
			"Speed" => "360 km/h",
			"Harga" => "80 Miliar"
		],
		[
			"no" => "8",
			"gambar" => "2.PNG",
			"Merek/Model" => "Koenigsegg Agera R",
			"Tahun Produksi" => "2015-2016",
			"Produksi Negara" => "Dubai",
			"Speed" => "370 km/h",
			"Harga" => "82 Miliar"
		],
		[
			"no" => "9",
			"gambar" => "2.PNG",
			"Merek/Model" => "Mclaren P1",
			"Tahun Produksi" => "2017-2018",
			"Produksi Negara" => "China",
			"Speed" => "320 km/h",
			"Harga" => "35 Miliar"
		],
		[
			"no" => "10",
			"gambar" => "2.PNG",
			"Merek/Model" => "Koenigsegg CCXR Trevita",
			"Tahun Produksi" => " 2004-2005",
			"Produksi Negara" => "Swedia",
			"Speed" => "320 km/h",
			"Harga" => "25 Miliar"
		],
	]







	 ?>

	 <H1 align= "center">Mobil</H1>

	 <table border="1" cellpadding="0" cellspacing="3">
	 	<tr align="center">
	 		<td width="50">no</td>
	 		<td>Gambar</td>
	 		<td width="200">Merek/Model</td>
	 		<td width="200">Tahun Produksi</td>
	 		<td width="200">Produksi Negara </td>
	 		<td width="200">Speed</td>
	 		<td width="200">Harga</td>
	 		
	 	</tr>
	 	<?php foreach ($Mobil as $Mobil) : ?>
	 		<tr>
	 			<td align="center"><?= $Mobil["no"] ?></td>
	 			<td align="center"><img src="../img/<?php echo $Mobil["gambar"]; ?>"></td>
	 			<td align="center"><?= $Mobil["Merek/Model"] ?></td>
	 			<td align="center"><?= $Mobil["Tahun Produksi"] ?></td>
	 			<td align="center"><?= $Mobil["Produksi Negara"] ?></td>
	 			<td align="center"><?= $Mobil["Speed"] ?></td>
	 			<td align="center"><?= $Mobil["Harga"] ?></td>
	 			
	 			
	 		</tr>
	 	<?php endforeach; ?>
	 	
	 </table>


</body>
</html>