<?php 
$nama = ["asa", "epan", "cipta", "akan", "u", "esok"];

echo ("M$nama[0] d$nama[1]mu di$nama[2]kan oleh apa yang kau kerj$nama[3] hari ini, b$nama[4]kan b$nama[5]");

echo "<br>";

 ?>