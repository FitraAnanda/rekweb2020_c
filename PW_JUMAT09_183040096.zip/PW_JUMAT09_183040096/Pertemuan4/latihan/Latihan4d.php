<?php 
	$komponen = [
			[
				"namaPerangkat" =>"Motherboard",
				"fungsi" => "Papan Sirkuit komponen komputer",
				"hargaBaru" => 500000,
				"hargaSekon" => 200000
			],
			[
				"namaPerangkat" =>"Processor",
				"fungsi" => "Sebuah IC yang mengontrol seluruh jalannya sistem komputer",
				"hargaBaru" => 300000,
				"hargaSekon" => 200000
			],
			[
				"namaPerangkat" =>"Hard Disk",
				"fungsi" => "Media Penyimpanan Sekunder",
				"hargaBaru" => 800000,
				"hargaSekon" => 500000
			],
			[
				"namaPerangkat" =>"PC Coller",
				"fungsi" => "Mengurangi panas yang di hasilkan oleh komputer",
				"hargaBaru" => 200000,
				"hargaSekon" => 100000
			],
			[
				"namaPerangkat" =>"VGA Card",
				"fungsi" => "Mengolah data grafik yang akan di tampilkan oleh monitor",
				"hargaBaru" => 900000,
				"hargaSekon" => 800000
			],
			[
				"namaPerangkat" =>"Optical Drive",
				"fungsi" => "Membaca, maupun menulis data dari kepingan CD",
				"hargaBaru" => 500000,
				"hargaSekon" => 300000
			],
			[
				"namaPerangkat" =>"Card Reader",
				"fungsi" => "Untuk membaca data data yang tersimpan di dalam memory card",
				"hargaBaru" => 10000,
				"hargaSekon" => 5000
			],
			[
				"namaPerangkat" =>"Modem",
				"fungsi" => "Mengubah sinyal digital menjadi sinyal analog",
				"hargaBaru" => 200000,
				"hargaSekon" => 150000
			]
		];	
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Latihan4d_183040096</title>
 </head>
 <body>
 	<table border="2" cellpadding="4" cellspacing="0">
 		<tr>
 			<th>No</th>
 			<th>Nama Perangkat</th>
 			<th>Fungsi</th>
 			<th>Harga Baru</th>
 			<th>Harga Sekon</th>
 		</tr>

 		<?php 
 		$No= 1;
 		$tHrgaBaru = 0;
 		$tHrgaSkon = 0;

		for ($k=0; $k < count($komponen); $k++){
 			
 			echo "<tr>";
 					echo "<td>$No</td>";
 					
 					echo "<td>" .$komponen[$k]["namaPerangkat"]."</td>";
 					echo "<td>" .$komponen[$k]["fungsi"]. "</td>";
 					echo "<td align = "."center"."> Rp. " .$komponen[$k]["hargaBaru"]. "</td>";
 					echo "<td align = "."center"."> Rp." .$komponen[$k]["hargaSekon"]. "</td>";
 			echo "</tr>";
 				$No++;
		
 		}
 		 ?>
 	</table>
 </body>
 </html>