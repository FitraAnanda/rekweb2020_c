<!DOCTYPE html>
<html>
<head>
	<title>Latihan - 4C</title>
</head>
<body>
	<?php

$perangkat = [
                 "Motherboard" => " Papan Sirkuit komponen komputer",
			"Processor" 	=> " Sebuah IC yang mengontrol seluruh jalannya sistem komputer",
			"Hard Disk" 	=> " Media Penyimpanan",
			"PC Coller" 	=> " Mengurangi panas yang di hasilkan oleh komputer",
			"VGA Card"  	=> " Mengolah data grafik yang akan di tampilkan oleh monitor",
			"Optical Drive" => " Membaca, maupun menulis data dari kepingan CD",
			"Card Reader" 	=> " Untuk membaca data data yang tersimpan di dalam memory card",
			"Modem" 		=> " Mengubah sinyal digital menjadi sinyal analog"
];
echo "<h2>Macam-macamm perangkat keras komputer dan fungsinya</h2>";
	foreach ($perangkat as $pr => $k) {
		echo "$pr :$k <br>";
		}
	?>

</body>
</html>

