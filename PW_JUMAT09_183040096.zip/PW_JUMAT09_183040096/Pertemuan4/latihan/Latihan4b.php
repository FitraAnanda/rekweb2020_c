<!DOCTYPE html>
<html>
<head>
	<title>Latihan4b_183040096</title>
</head>
<body>
	<?php 
		$komputer = ["Motherboard","Processor","Hardisk", "Pc Coller","VGA Card", "SSD"];
		echo "<h4>Macam - macam perangkat keras komputer </h4>";
		echo "<ul>";

		for ($i=0; $i < count($komputer) ; $i++) 
		{ 
			echo "<li>$komputer[$i]</li>";
		}
		echo "</ul>";

		$komputer[] = "Card reader";
		$komputer[] = "Modem";
		$a = sort($komputer);

		echo "<h4>Macam - macam perangkat keras komputer  baru</h4>";

		for ($i=0; $i < count($komputer) ; $i++) 
		{ 
			echo "<li>$komputer[$i]</li>";
		}
	?>


</body>
</html>