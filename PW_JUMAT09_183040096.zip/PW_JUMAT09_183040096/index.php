<!DOCTYPE html>
<html>
<head>
	<title>Index php</title>
	<style>
		.link{

			color: skyblue;
			background-color: grey;
			
		}
	</style>
</head>
<body>
	<?php 
	print"<div class='link'>
		<h1>Daftar Link</h1>

		<h2>PERTEMUAN3</h2>
			<h3><a href='pertemuan3/Latihan1a.php'></a>Latihan3a</h3>
			<h3><a href='pertemuan3/Latihan1b.php'></a>Latihan3b</h3>
			<h3><a href='pertemuan3/Latihan1c.php'></a>Latihan3c</h3>
			<h3><a href='pertemuan3/Latihan1c.php'></a>Latihan3d</h3>

		<h2>PERTEMUAN4</h2>
			<h3><a href='pertemuan4/latihan/Latihan4a.php'></a>Latihan4a</h3>
			<h3><a href='pertemuan4/latihan/Latihan4b.php'></a>Latihan4b</h3>
			<h3><a href='pertemuan4/latihan/Latihan4c.php'></a>Latihan4c</h3>
			<h3><a href='pertemuan4/latihan/Latihan4d.php'></a>Latihan4d</h3>
			<h3><a href='pertemuan4/tugas/Tugas2.php'></a>Tugas2</h3>

		</div>

	</div>
</body>
</html>
